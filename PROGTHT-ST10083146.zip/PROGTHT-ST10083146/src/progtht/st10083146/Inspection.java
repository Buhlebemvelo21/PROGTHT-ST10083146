
package progtht.st10083146;


public class Inspection {
    
    
    private String hospitallocation; 
    private String hospitalname;
    private int years;
    
    public Inspection(String hospitallocation, String hospitalname, int year) {
        this.hospitallocation = hospitallocation;
        this.hospitalname = hospitalname;
        this.years = years;
        
    }

    public String getHospitallocation() {
        return hospitallocation;
    }

    public String getHospitalname() {
        return hospitalname;
    }

    public int getYears() {
        return years;
    }
    
}
    class Hospital extends Inspection {
        Boolean due;
        @SuppressWarnings("empty-statement")
        public Hospital(int years, String hospitalname){
            super (hospitalname,years);
            if(years>=2){
                due = true;
                
            }else{
                due =false;
                
            }        
            }
        public Boolean getDue(){
            return due;
            
         }
        
        
    }
