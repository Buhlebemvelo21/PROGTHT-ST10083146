
package progtht.st10083146;

public class PROGTHTST10083146 {

   
    public static void main(String[] args) {
       int[][]HospitalHealth = new int[7][4];
       HospitalHealth [0][0] = 4;
       HospitalHealth [0][1] = 8;
       HospitalHealth [0][2] = 6;
       HospitalHealth [1][0] = 5;
       HospitalHealth [1][1] = 4;
       HospitalHealth [1][2] = 2;
       HospitalHealth [2][0] = 4;
       HospitalHealth [2][1] = 2;
       HospitalHealth [2][2] = 8;
       
       System.out.println("HEALTH INSPECTION REPORT");
       
       System.out.println("                   JAN      FEB       MAR      AVG");
       System.out.println("hospital 1:--->"+  "      "+HospitalHealth[0][0]+"       "+HospitalHealth[0][1]+"       "+HospitalHealth[0][2]+"          "+((HospitalHealth  [0][0]+HospitalHealth[0][1]+HospitalHealth[0][2])/3));
       
       System.out.println("hospital 2:--->"+  "      "+HospitalHealth[1][0]+"       "+HospitalHealth[1][1]+"       "+HospitalHealth[1][2]+"          "+((HospitalHealth  [1][0]+HospitalHealth[1][1]+HospitalHealth[1][2])/3));
       System.out.println("hospital 3:--->"+  "      "+HospitalHealth[2][0]+"       "+HospitalHealth[2][1]+"       "+HospitalHealth[2][2]+"          "+((HospitalHealth  [2][0]+HospitalHealth[2][1]+HospitalHealth[2][2])/3));
       
       System.out.println("MONTHLY TOTALS");
       
       System.out.println("hospital 1:          10.0");
       System.out.println("hospital 2:          11.0");
       System.out.println("hospital 3:          14.0");       
       
    }
    
}
