
package progtht.st10083146;


public class Question2ProgTHT {
    
    public static void main(String[]args){
        ArrayList <Inspection> InspectionList = new ArrayList<Inspection>();
        
    }
    
}
